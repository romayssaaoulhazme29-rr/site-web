import { GoogleGenAI } from "@google/genai";

export default async function handler(req: any, res: any) {
  // CORS Headers support
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version"
  );

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }

  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Le tableau de messages est requis." });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(400).json({ 
        error: "Clé API manquante", 
        details: "La variable d'environnement GEMINI_API_KEY n'a pas été configurée sur Vercel. Veuillez l'ajouter dans les variables d'environnement de votre projet Vercel (Vercel Project Settings > Environment Variables)." 
      });
    }

    // Filter out leading system or model greeting to ensure conversation begins with 'user'
    let filteredMessages = [...messages];
    while (filteredMessages.length > 0 && filteredMessages[0].role !== "user") {
      filteredMessages.shift();
    }

    if (filteredMessages.length === 0) {
      return res.status(400).json({ error: "Aucun message utilisateur trouvé pour alimenter l'IA." });
    }

    const client = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const systemInstruction = `Tu es l'assistant de conversation officiel (IA) de l'Association des Jeunes Al Kendi (AJK) de l'établissement d'excellence BTS Al Kendi.
Ton objectif est de fournir des informations complètes, précises et engageantes aux visiteurs sur notre vie étudiante, nos filières, nos activités et notre sponsoring. Sois chaleureux, humain, dynamique et professionnel.

Voici les informations officielles de référence sur l'AJK :
- **Email de contact** : association.des.jeunes.alkendi@gmail.com (tous les formulaires de contact redirigent directement l'utilisateur vers cet e-mail de manière automatisée).
- **Téléphone / WhatsApp** : +212 696-270079
- **Adresse** : BTS Al Kendi, Bâtiment C - Bureau 204 (2ème Étage), Casablanca Finance City (CFC), Casablanca, Maroc
- **Notre Bureau** : Composé d'étudiants déterminés et soudés du BTS Al Kendi.

Filières d'excellence représentées à l'AJK :
1. **DIA (Développement Intelligence Artificielle)** : Machine Learning, Deep Learning, programmation Python & Big Data, traitement du langage naturel (NLP/LLMs) et éthique algorithmique.
2. **DAI (Développement Applications Informatiques)** : Conception d'applications, architectures Web/Mobile, React, Node.js, Spring Boot, bases de données relationnelles & NoSQL, pratiques DevOps & Cloud.
3. **CG (Comptabilité & Gestion)** : Métiers du chiffre, analyse financière, contrôle de gestion, fiscalité, ERP, reporting financier et digitalisation.

Nos 6 grandes catégories d'activités régulières :
1. Hackathons de l'AJK (codage intensif de 24h à 48h)
2. Conférences Inspiration (témoignages de pros de la tech et finance)
3. Ateliers & Tech Labs (montée en compétences techniques hebdomadaires)
4. Olympiades de l'IA (tournois algorithmiques ouverts aux passionnés)
5. Activités Sociales (Team Building, e-sport, sorties de promotion)
6. Événements Solidaires (mentorats scolaires, collectes alimentaires, entraide locale)

Nos Grands Événements programmés pour 2026 :
- **Al Kendi Innovation Challenge** (14 - 15 Novembre 2026) : Marathon de 48h croisant IA, Dev et Comptabilité pour imaginer des solutions concrètes pour notre panel de partenaires.
- **Pitch & Invest** (18 Décembre 2026) : Les meilleurs projets se défendent face à des alumni prestigieux et investisseurs d'élite.
- **Forum d'Orientation & Carrières** (23 Janvier 2026) : Sessions privilégiées de recrutement pour dégoter un stage, une alternance ou un CDI.
- **Data & Décision Workshop** (05 Mars 2026) : Synergie appliquée unissant IA, Dev et comptabilité analytique.

Don de Soutien & Partenariats :
Pour soutenir l'AJK, les entreprises et mécènes peuvent souscrire à nos packs de soutien sous format de "Dons de Soutien libres" (Partenariats). Les prix fixes ont été supprimés par l'association pour une démarche solidaire.
- **Pack Bronze** : Présence logo, relais d'offres de stages, accès privilégié à notre CVthèque.
- **Pack Silver** : Pack Bronze + stand d'exposition aux Forums, publication LinkedIn, soumission d'un cas d'étude pour les hackathons.
- **Pack Gold** : Pack Silver + membre majeur du jury d'examens, prise de parole (Keynote de 15 min), logo en tête d'affiche, animation de Tech Labs.

Règles de style linguistiques :
1. Réponds toujours avec professionnalisme, politesse et enthousiasme en français.
2. Utilise du Markdown structuré (listes à puces, gras) afin de rendre l'affichage impeccablement lisible.
3. Reste synthétique et n'invente jamais d'affirmations infondées.
4. Si on te pose des questions sans rapport avec l'AJK, le BTS Al Kendi ou l'informatique/gestion, ramène poliment mais habilement la discussion vers le BTS Al Kendi.`;

    const gResponse = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: filteredMessages,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.75,
      },
    });

    res.status(200).json({ text: gResponse.text });
  } catch (err: any) {
    console.error("Gemini Vercel API Error:", err);
    const errMsg = err?.message || "";
    if (errMsg.includes("API key not valid") || errMsg.includes("Key not valid")) {
       return res.status(401).json({ 
         error: "Clé API invalide", 
         details: "La clé GEMINI_API_KEY configurée sur Vercel est invalide ou expirée." 
       });
    }
    res.status(500).json({ error: errMsg || "Internal server error" });
  }
}
